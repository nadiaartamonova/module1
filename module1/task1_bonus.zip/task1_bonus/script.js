{
    const productName = 'Apples';
    const quentity = 12;
    const productCategory = 'Fruts';
    const productPrice = 5;

    console.log("Продукт: ", productName);

    const cartPrice = quentity * productPrice;
    console.log("Стоимость покупки: ", cartPrice);

}